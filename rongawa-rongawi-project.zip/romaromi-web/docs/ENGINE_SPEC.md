# RomaRomi typing engine — specification

Recovered from the p-code of the 2002 program (Clipper 5.01, procedures `BUKA`, `KETIK`, `AKHIR`) and checked
against the original running in DOSBox. Implementation: `src/engine.js`; tests: `test/engine.test.js`.

## Flow
1. **Menu (`BUKA`)** – the student enters: exercise code (3 chars, e.g. `01D`), registration number (10 digits),
   full name (20 chars), time limit in seconds (blank / Enter = unlimited). Empty code + Enter or Esc = quit.
   - Hidden code **`MIA`** shows the list of today's results (teacher view).
   - Unknown code → "Kode tersebut tidak ada !!!".
2. **Typing (`KETIK`)** – 8 lines per page, double-spaced: target line, typed characters directly underneath,
   `↑` marker under the next character. Header: date · `[ NAME - NUMBER ]` · clock. Pages advance after 8 lines.
3. **Results** – per-finger table (Total / Salah / %), time used, accuracy, speed, three grades. The original
   swallowed 6 keypresses before accepting Enter (guard against skipping the screen by accident).

## Keystroke rules (identical in 2002 and the rebuild unless marked)
| Rule | Behaviour |
|---|---|
| Comparison | Each key is compared with the character at the cursor. **The cursor always advances.** |
| Wrong key | 1 error, charged to the finger that **should** have typed the expected character. Beep. |
| Correct key | Credited to the finger that typed it. |
| Skipped / extra character | Not resynchronised: every following character on that line is misaligned and wrong (deliberate harshness). |
| Backspace, Tab | Count as wrong keys and advance — there is no correction. |
| Arrows, Del, modifiers | Ignored. |
| End of line | One extra key (normally Enter) moves to the next line; it is not scored. Finishing the last line ends the test. |
| Enter before end of line | 2002: accepted one character early (off-by-one → extra error). **Rebuild: ignored.** |
| Display | Correct chars yellow, wrong chars red, a wrong space shows as ☺. |
| Clock | Starts at the first accepted keystroke, not when the screen appears. |
| Time limit | 2002: polled once a second, overshot by ~1 s and displayed "time − 1" to hide it. **Rebuild: ends exactly at the limit.** |
| Esc | Aborts without a result — except **23I**, the exam text ("Esc > No Way"). |
| Characters without a finger | 2002: the backtick `` ` `` was in no finger set, so it was never scored. **Rebuild: left little finger** (with `~`). |

Finger key sets (2002): left little `1qaz!QAZ`, left ring `2wsx@WSX`, left middle `3edc#EDC`,
left index `4rfv5tgb$RFV%TGB`, right index `6yhn7ujm^YHN&UJM`, right middle `8ik,*IK<`, right ring `9ol.(OL>`,
right little `0p;/-'=)P:?_{"+}|\[]`, thumb: space.

## Scoring
- Keystrokes = correct + wrong (end-of-line keys excluded).
- Accuracy = 100 − wrong ÷ keystrokes × 100, rounded to a whole number (Clipper `STR()` rounding).
- Speed (epm, *entakan per menit*) = keystrokes ÷ minutes, rounded. 2002 used whole-second `TIME()`; the rebuild uses ms.
- Per finger: % = wrong ÷ (correct + wrong) × 100, rounded.

| Accuracy | Grade | | Speed (epm) | Grade |
|---|---|---|---|---|
| 100 | 10 | | ≥ 270 | 10 |
| 99 | 9.5 | | 255–269 | 9.5 |
| 98 | 9 | | 240–254 | 9 |
| 97 | 8.5 | | 225–239 | 8.5 |
| 96 | 8 | | 210–224 | 8 |
| 95 | 7.5 | | 195–209 | 7.5 |
| 94 | 7 | | 170–194 | 7 |
| 93 | 6.5 | | 155–169 | 6.5 |
| 92 | 6 | | 140–154 | 6 |
| ≤ 91 | 0 | | ≤ 139 | 0 |

Final grade = (accuracy grade + speed grade) ÷ 2. The table is **unchanged from 2002**: all ranges are inclusive and
contiguous. (An earlier reading of the p-code assumed opcode `0x68` was `<`, which made the edges 91, 269, 254, … look
ungraded; a live test proved `0x68` is `<=`, so the original grading was correct.)

## Other 2002 behaviour not (yet) carried over
- Results table kept **only today**: the first save of a new day, or opening `MIA` on a day with no results,
  deleted all older results. To be replaced by proper history with central storage.
- Midnight bug: durations crossing 00:00 went negative (rebuild uses real timestamps).

## Verification
Differential test, 78 keystrokes on 01D with a substitution, Backspace, a wrong-case letter, an omission
(cascade), a wrong space and an end-of-line key: per-finger Total/Salah/% for all 9 fingers, total keystrokes
(77) and accuracy (29 %) are **identical** between the engine and the original in DOSBox
(`screens/differential_test_original.png`). Speed: original 76 epm (61 s measured for a 60 s limit), engine
77 epm (exactly 60 s) — the intended time-limit fix.
