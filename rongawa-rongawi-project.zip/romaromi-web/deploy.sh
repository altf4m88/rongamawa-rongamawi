#!/usr/bin/env bash
# Deploy RomaRomi to Cloud Run (builds the container with Cloud Build from this folder).
#
#   PROJECT=my-project ./deploy.sh                  # private: only Google accounts you grant can open it
#   PROJECT=my-project ACCESS=password ./deploy.sh  # anyone with the link + the shared password (lab testers)
#
# Optional: REGION (default asia-southeast2 = Jakarta), SERVICE (default romaromi),
#           AUTH_USER (default guru), SECRET (default romaromi-test-password; Secret Manager secret name).
set -euo pipefail
PROJECT="${PROJECT:?Set PROJECT to your Google Cloud project ID, e.g. PROJECT=my-project ./deploy.sh}"
REGION="${REGION:-asia-southeast2}"
SERVICE="${SERVICE:-romaromi}"
ACCESS="${ACCESS:-private}"
AUTH_USER="${AUTH_USER:-guru}"
SECRET="${SECRET:-romaromi-test-password}"
cd "$(dirname "$0")"

gcloud services enable run.googleapis.com cloudbuild.googleapis.com artifactregistry.googleapis.com \
  secretmanager.googleapis.com --project "$PROJECT"

args=(--project "$PROJECT" --region "$REGION" --source . --port 8080
      --cpu 1 --memory 512Mi --min-instances 0 --max-instances 2 --concurrency 80 --timeout 30)

case "$ACCESS" in
  private)
    args+=(--no-allow-unauthenticated)
    # switching an existing "password" deployment back to private: drop the login settings
    if gcloud run services describe "$SERVICE" --project "$PROJECT" --region "$REGION" >/dev/null 2>&1; then
      args+=(--remove-env-vars BASIC_AUTH_USER --remove-secrets BASIC_AUTH_PASSWORD)
    fi ;;
  password)
    if ! gcloud secrets describe "$SECRET" --project "$PROJECT" >/dev/null 2>&1; then
      echo "Creating secret $SECRET with a random password."
      head -c 18 /dev/urandom | base64 | tr -d '/+=\n' | gcloud secrets create "$SECRET" --project "$PROJECT" --data-file=-
    fi
    number=$(gcloud projects describe "$PROJECT" --format='value(projectNumber)')
    gcloud secrets add-iam-policy-binding "$SECRET" --project "$PROJECT" --quiet >/dev/null \
      --member "serviceAccount:${number}-compute@developer.gserviceaccount.com" --role roles/secretmanager.secretAccessor
    args+=(--allow-unauthenticated --set-env-vars "BASIC_AUTH_USER=$AUTH_USER"
           --set-secrets "BASIC_AUTH_PASSWORD=$SECRET:latest") ;;
  *) echo "ACCESS must be 'private' or 'password'"; exit 1 ;;
esac

gcloud run deploy "$SERVICE" "${args[@]}"
url=$(gcloud run services describe "$SERVICE" --project "$PROJECT" --region "$REGION" --format='value(status.url)')
echo
if [ "$ACCESS" = private ]; then
  echo "Deployed (private): $url"
  echo "Open it through an authenticated tunnel:"
  echo "  gcloud run services proxy $SERVICE --project $PROJECT --region $REGION --port 8080"
  echo "  then browse to http://localhost:8080"
else
  echo "Deployed (password): $url   user: $AUTH_USER"
  echo "Show the password:  gcloud secrets versions access latest --secret $SECRET --project $PROJECT"
fi
