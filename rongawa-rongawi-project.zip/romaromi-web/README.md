# RomaRomi web

Web rebuild of **RomaRomi "Flicking Test"**, the 2002 DOS typing tutor. Same exercises, same screens, same scoring,
without the self-destruct code of the original. Runs in any modern browser on Windows, Linux, macOS or ChromeOS.

## Run it
Open **`dist/romaromi.html`** in a browser (double-click). It is one self-contained file: no install, no server,
works offline. Click the screen, then type.

- Exercise codes: `01D`–`08D` drills, `01I`–`28I` Indonesian, `01E`–`15E` English. `23I` is the exam text (Esc is locked).
- `MIA` (hidden teacher code from the original) lists today's results.
- Results are stored in this browser only, until central storage is built.

## Change the school details
Edit `src/config.js` (school name, address, notice text), then rebuild:

    npm run build     # writes dist/romaromi.html and dist/artifact.html
    npm test          # builds, then runs engine + server tests (Node 20+, no dependencies)
    npm start         # serves the app on http://localhost:8080

## Deploy to Cloud Run
`PROJECT=your-project-id ./deploy.sh` — private by default. See **DEPLOY.md**.

## Layout
| Path | |
|---|---|
| `src/engine.js` | typing engine: keystroke rules, per-finger statistics, grading (verified against the original) |
| `src/app.js` | the screens: menu, typing, results, `MIA` report, exit, CRT power-off animation |
| `src/vga.js`, `src/font.js`, `src/cp437.js` | 80×25 VGA text screen with the real 8×16 ROM font and Clipper colour strings |
| `src/config.js` | school / edition texts |
| `web/shell.html` | the page around the screen |
| `server/server.js` | Cloud Run server: serves the app with strict security headers, optional password |
| `Dockerfile`, `deploy.sh` | container (tests run during the build) and one-command Cloud Run deploy |
| `data/exercises.json` | 52 exercises (see `data/EXPORT_NOTES.md`) |
| `docs/ENGINE_SPEC.md` | behaviour recovered from the original and every deliberate difference |
| `tools/` | `build.mjs` (bundle into one HTML file), `export_exercises.py` (legacy DBF → JSON, Python) |

## Verified
- Engine: 15 unit tests; a 78-keystroke script full of mistakes produces the **same per-finger table, keystroke
  count and accuracy** as the original running in DOSBox (`docs/screens/differential_test_original.png`).
- Browser build: the same script run end-to-end in Chromium gives identical numbers; unknown code, `MIA`, Esc abort,
  exam lock and exit flow checked; no console errors; no horizontal scrolling at 400 px.

## Differences from 2002 (all deliberate)
Time limit ends exactly on time · Enter is not accepted one character early · backtick is scored (left little finger) ·
results screen ignores keys for 1.5 s instead of swallowing six keypresses · no usage counter, no file deletion ·
school details come from `src/config.js` · results kept per day instead of wiping older days.

Not built yet: central results storage (results are kept per browser).
