// Texts that identify the school or the edition. Everything else on screen comes from the 2002 program.
// Keep each line within the width noted, or it will run into the frames.
export const CONFIG = {
  // Menu footer lines 20–22 (≤ 78 chars) and the label on the typing box frame (schoolLine ≤ 50 chars).
  schoolLine: "Nama Sekolah < Motto Sekolah >",
  addressLine: "Alamat Sekolah, Kota, Telepon",
  contactLine: "Situs web / e-mail sekolah",

  // Menu notice box, rows 10–16 (≤ 60 chars each, max 7 lines).
  notice: [
    "Selamat datang di RomaRomi, latihan mengetik 10 jari.",
    "Pilih kode latihan, isi nomor registrasi dan nama,",
    "lalu tentukan batas waktu (Enter = waktu tidak dibatasi).",
    "Ketik teks baris demi baris. Salah ketik tidak bisa",
    "dihapus: Backspace juga dihitung salah. Esc = batal.",
    "Nilai dihitung dari ketelitian dan kecepatan (epm).",
    "Edisi web dari RomaRomi Flicking Test (2002).",
  ],
  noticeTitle: "P E R H A T I A N   !!!! ",
  greeting: "Salam Hangat RomaRomi",
  edition: "Web Edition - 2026",

  // Vertical texts beside the typing box: left ≤ 17 chars, right ≤ 17 chars.
  verticalLeft: "Web Edition",
  verticalRight: "Based on RomaRomi",

  // Results screen footer: left (≤ 18 chars) and centre.
  resultsLeft: "Web Edition",
  resultsCentre: "berdasarkan RômâRômî 2002",
};
