// Screens of RomaRomi, rebuilt from the 2002 program's own drawing code (procedures BUKA, KETIK, AKHIR,
// LAYUR, WINDOWS). Row/column positions and colour strings are the original ones unless noted.
import { Screen } from "./vga.js";
import { cp437 } from "./cp437.js";
import { createSession } from "./engine.js";
import { CONFIG } from "./config.js";

const LINES_PER_PAGE = 8;
const STORE_KEY = "romaromi.results.v1";

/** Clipper STR(n, width, decimals): right-aligned, '*' when it does not fit. */
function STR(n, width, dec = 0) {
  const s = Number(n).toFixed(dec);
  return s.length > width ? "*".repeat(width) : s.padStart(width);
}
const centre = (text, width = 80) => Math.trunc((width - [...text].length) / 2);
const two = (n) => String(n).padStart(2, "0");
const dateText = (d = new Date()) => `${two(d.getDate())}-${two(d.getMonth() + 1)}-${d.getFullYear()}`;
const timeText = (d = new Date()) => `${two(d.getHours())}:${two(d.getMinutes())}:${two(d.getSeconds())}`;

/** "Waktu yang Anda Gunakan" value, in the original's three layouts (without its "minus one second"). */
function durationText(sec) {
  if (sec >= 3600) {
    const h = Math.floor(sec / 3600);
    const rest = sec - h * 3600;
    return rest >= 60
      ? `${STR(h, 2)} jam ${STR(Math.floor(rest / 60), 2)} menit ${STR(rest % 60, 2)} detik`
      : `${STR(h, 2)} jam ${STR(rest, 2)} detik`;
  }
  if (sec >= 60) return `${STR(Math.floor(sec / 60), 2)} menit ${STR(sec % 60, 2)} detik`;
  return `${STR(sec, 2)} detik`;
}

function loadResults() {
  try {
    return JSON.parse(localStorage.getItem(STORE_KEY)) || [];
  } catch {
    return [];
  }
}
function saveResults(list) {
  try {
    localStorage.setItem(STORE_KEY, JSON.stringify(list.slice(-500)));
  } catch {
    /* storage unavailable: results stay in memory for this visit */
  }
}

const isPrintable = (k) => [...k].length === 1 && k >= " ";

export class App {
  constructor(canvas, exercises, { beep = () => {} } = {}) {
    this.s = new Screen(canvas);
    this.exercises = new Map(exercises.map((e) => [e.code, e]));
    this.beep = beep;
    this.results = loadResults();
    this.form = { code: "", reg: "", nama: "", detik: "" };
    this.lastResult = null;
    this.mode = null;
    const max = (suffix) => Math.max(...exercises.filter((e) => e.code.endsWith(suffix)).map((e) => parseInt(e.code, 10)));
    this.hint = `< 01I s.d. ${two(max("I"))}I atau 01E s.d. ${two(max("E"))}E >`;
    this.start();
  }

  start() {
    this.sessionStart = Date.now();
    this.goMenu();
  }

  setMode(mode) {
    this.mode = mode;
    this.s.cursor.visible = false;
    mode.enter?.();
  }

  key(k, now = performance.now()) {
    this.mode?.key?.(k, now);
  }

  tick(now = performance.now()) {
    this.mode?.tick?.(now);
    this.s.render(now);
  }

  /** Bottom-line message, then wait for any key (the original's SET CONSOLE OFF; WAIT ""). */
  message(row, col, text, color, then) {
    const s = this.s;
    s.say(row, 0, " ".repeat(80), color);
    s.say(row, col, text, color);
    s.cursor.visible = false;
    this.mode = { key: () => then() };
  }

  // ───────────────────────────── BUKA: menu and registration form ─────────────────────────────
  goMenu(phase = "code") {
    const app = this;
    const s = this.s;
    const f = this.form;
    if (phase === "code") Object.assign(f, { code: "", reg: "", nama: "", detik: "" }); // BUKA resets every field
    const exercise = () => this.exercises.get(f.code);
    const fields = {
      code: { row: 2, col: 28, len: 3, ok: (ch) => /[0-9A-Z]/.test(ch) },
      reg: { row: 3, col: 28, len: 10, ok: (ch) => /[0-9]/.test(ch) },
      nama: { row: 4, col: 28, len: 20, ok: (ch) => ch >= " " && cp437(ch) !== 0x3f || ch === "?" },
      detik: { row: 6, col: 28, len: 3, ok: (ch) => /[0-9]/.test(ch) },
    };
    let order = ["code"];
    let active = 0;

    function drawField(name) {
      const fd = fields[name];
      const hidden = name === "code" && f.code.startsWith("M"); // after "M" the original typed invisibly
      s.say(fd.row, fd.col, f[name].padEnd(fd.len), hidden ? "bg/bg" : "w+/bg");
    }
    function placeCursor() {
      const fd = fields[order[active]];
      s.cursor.row = fd.row;
      s.cursor.col = fd.col + Math.min(f[order[active]].length, fd.len - 1);
      s.cursor.visible = true;
    }
    function draw() {
      s.setColor("bg+/b,w+/bg");
      s.clear();
      CONFIG.notice.slice(0, 7).forEach((line, i) => s.say(10 + i, 10, line));
      s.bevel(0, 2, 74, 22, 8);
      s.bevel(8, 7, 64, 10, 7);
      s.say(18, 52, CONFIG.edition, "g+*/b");
      s.say(18, 10, CONFIG.greeting, "g+*/b");
      s.say(9, centre(CONFIG.noticeTitle), CONFIG.noticeTitle, "gr+*/b");
      s.say(20, centre(CONFIG.schoolLine), CONFIG.schoolLine, "gr+/b");
      s.say(21, centre(CONFIG.addressLine), CONFIG.addressLine, "gr+/b");
      s.say(22, centre(CONFIG.contactLine), CONFIG.contactLine, "gr+/b");
      s.say(24, 0, " ".repeat(80), "gr+/n");
      s.say(24, 27, "Tekan Enter/Esc =\u25ba Keluar", "gr+/n");
      s.setColor("w+/b,w+/bg");
      s.say(2, 6, "Pilih Kode Latihan : ");
      s.say(2, 32, app.hint);
      s.say(1, 36, "┌─►");
      s.say(1, 39, "Teks Bhs. Indonesia");
      s.say(3, 54, "└─►");
      s.say(3, 57, "Teks Bhs. Inggris");
      s.say(3, 6, "Nomor Registrasi   : ");
      s.say(4, 6, "Nama Lengkap       : ");
      s.say(6, 6, "Waktu Penyelesaian :      Detik" + " ".repeat(40));
      for (const name of Object.keys(fields)) drawField(name);
      if (phase === "details") {
        s.say(24, 0, " ".repeat(80), "w+/b");
        if (!isExam()) s.say(6, 32, "Detik <Tekan Enter \u2500\u25ba Waktu Tidak Dibatasi>");
      }
      placeCursor();
    }
    const isExam = () => f.code === "23I";

    function submitCode() {
      if (f.code === "") return app.goExit();
      if (f.code === "MIA") return app.goReport();
      if (!exercise()) {
        return app.message(24, 26, "Kode tersebut tidak ada !!!", "gr+/n", () => app.goMenu());
      }
      app.goMenu("details");
    }
    function submitDetails() {
      if (!f.reg.trim() || !f.nama.trim()) {
        return app.message(24, 22, "Isi No. Registrasi dan Nama Anda !!!", "gr+/n", () => app.goMenu("details"));
      }
      app.goTyping(exercise(), isExam() ? null : parseInt(f.detik, 10) || null);
    }
    function next() {
      if (active < order.length - 1) {
        active += 1;
        placeCursor();
      } else if (phase === "code") submitCode();
      else submitDetails();
    }

    if (phase === "details") {
      order = isExam() ? ["reg", "nama"] : ["reg", "nama", "detik"];
    }
    this.setMode({
      enter: draw,
      key(k) {
        const name = order[active];
        const fd = fields[name];
        if (k === "Escape") return phase === "code" ? app.goExit() : app.goMenu();
        if (k === "Enter" || k === "ArrowDown" || k === "Tab") return next();
        if (k === "ArrowUp") {
          if (active > 0) active -= 1;
          return placeCursor();
        }
        if (k === "Backspace") {
          f[name] = f[name].slice(0, -1);
          drawField(name);
          return placeCursor();
        }
        if (!isPrintable(k)) return;
        const ch = name === "detik" || name === "reg" ? k : k.toUpperCase();
        if (!fd.ok(ch) || f[name].length >= fd.len) return;
        f[name] += ch;
        drawField(name);
        placeCursor();
        if (f[name].length === fd.len) next(); // SET CONFIRM OFF: a full field moves on by itself
      },
    });
  }

  // ───────────────────────────── KETIK: the typing test ─────────────────────────────
  goTyping(exercise, timeLimitSec) {
    const app = this;
    const s = this.s;
    const f = this.form;
    const session = createSession(exercise, { timeLimitSec });
    const lines = exercise.lines;
    let marker = null;
    let shownSecond = -1;

    const pageOf = (line) => Math.floor(line / LINES_PER_PAGE);
    const targetRow = (line) => 4 + 2 * (line % LINES_PER_PAGE);

    function drawFrame() {
      s.setColor("rb/n+");
      for (let r = 0; r <= 23; r++) s.say(r, 0, "▒".repeat(80));
      s.setColor("bg+/rb");
      for (let r = 1; r <= 23; r++) {
        s.say(r, 0, "   ");
        s.say(r, 77, "   ");
      }
      const teks1 = `[ ${f.nama.trim()} - ${f.reg.trim()} ]`;
      const teks3 = "Tes Ketepatan, Kecepatan & Mengalisis Kesalahan Jari-jari Anda < Flicking Test >";
      s.say(0, 0, " ".repeat(80));
      s.say(24, 0, " ".repeat(80));
      s.say(0, centre(teks1), teks1);
      s.say(0, 3, dateText());
      s.say(0, 69, timeText());
      s.say(24, Math.max(0, centre(teks3)), teks3);
      for (let i = 0; i < 17; i++) {
        s.say(6 + i, 1, CONFIG.verticalLeft[i] ?? "");
        s.say(4 + i, 78, CONFIG.verticalRight[i] ?? "");
      }
      for (let r = 4; r <= 20; r++) s.say(r, 5, "░".repeat(72), "rb/n+");
      s.setColor("w+/b");
      s.fill(3, 3, 20, 74);
      s.box(3, 3, 20, 74);
      s.say(20, 58, session.exam ? "Esc > No Way" : "Esc =\u25ba Batal", "gr+*/b");
      const teks4 = `┤ Kode Latihan : ${exercise.code.slice(0, 2)}-${exercise.code.slice(-1)} ├`;
      const teks5 = `┤ ${CONFIG.schoolLine} ├`;
      s.say(3, Math.trunc((78 - [...teks4].length) / 2), teks4, "bg+/b");
      s.say(20, Math.trunc((62 - [...teks5].length) / 2), teks5, "bg+/b");
    }
    function drawPage(page) {
      s.fill(4, 4, 19, 73, " ", "w+/b");
      for (let i = page * LINES_PER_PAGE; i < Math.min(lines.length, (page + 1) * LINES_PER_PAGE); i++) {
        s.say(targetRow(i), 4, lines[i], "w+/b");
      }
    }
    function drawMarker() {
      if (marker) s.say(marker.row, marker.col, " ", "w+/b");
      const { line, col } = session.position;
      marker = { row: targetRow(line) + 1, col: 4 + col };
      s.putCode(marker.row, marker.col, 0x18, "bg+*/b");
    }
    function finish() {
      app.goResults(exercise, session.result());
    }

    this.setMode({
      enter() {
        drawFrame();
        drawPage(0);
        drawMarker();
      },
      key(k, now) {
        const ev = session.press(k, now);
        switch (ev.type) {
          case "correct":
          case "wrong": {
            const row = targetRow(ev.line) + 1;
            const col = 4 + ev.col - 1;
            const code = ev.type === "correct" ? cp437(ev.key) : ev.key === " " ? 0x01 : ev.key.charCodeAt(0) < 32 ? ev.key.charCodeAt(0) : cp437(ev.key);
            s.putCode(row, col, code, ev.type === "correct" ? "gr+/b" : "r+/b");
            marker = null;
            if (ev.type === "wrong") app.beep();
            drawMarker();
            break;
          }
          case "newline":
            if (pageOf(ev.line) !== pageOf(ev.line - 1)) {
              marker = null;
              drawPage(pageOf(ev.line));
            }
            drawMarker();
            break;
          case "finished":
          case "timeout":
            finish();
            break;
          case "aborted":
            app.goMenu();
            break;
          default:
        }
      },
      tick(now) {
        if (session.tick(now)) return finish();
        const sec = Math.floor(Date.now() / 1000);
        if (sec !== shownSecond) {
          shownSecond = sec;
          s.say(0, 69, timeText(), "bg+/rb");
        }
      },
    });
  }

  // ───────────────────────────── results screen ─────────────────────────────
  goResults(exercise, r) {
    const app = this;
    const s = this.s;
    const f = this.form;
    this.lastResult = r;
    const record = {
      date: dateText(), reg: f.reg.trim(), nama: f.nama.trim(), code: exercise.code,
      speed: r.speed, accuracy: r.accuracy, keystrokes: r.keystrokes, grade: r.grade,
    };
    this.results.push(record);
    saveResults(this.results);

    s.setColor("w+/rb");
    s.clear();
    s.bevel(0, 1, 76, 19, 6);
    s.bevel(4, 10, 57, 11, 5);
    s.bevel(1, 4, 70, 1, 6);
    s.bevel(21, 1, 76, 1, 6);
    s.setColor("g+/rb");
    s.say(22, centre(CONFIG.resultsCentre), CONFIG.resultsCentre);
    s.say(22, 3, CONFIG.resultsLeft);
    s.say(22, 77 - dateText().length, dateText());
    s.setColor("w+/rb");
    s.say(2, 6, "Nama : [ ");
    s.say(2, 35, " ]  No : [ ");
    s.say(2, 56, " ]  Kode : [ ");
    s.say(2, 72, " ]");
    s.say(2, 15, f.nama.padEnd(20));
    s.say(2, 46, f.reg.padEnd(10));
    s.say(2, 69, exercise.code);
    s.say(5, 14, "       Jari              Total      Salah       %");
    s.say(6, 10, "├", "w/rb");
    s.say(6, 11, "─".repeat(57), "w/rb");
    s.say(6, 68, "┤", "n/rb");
    r.perFinger.forEach((fg, i) => {
      s.say(7 + i, 15, `${fg.name.padEnd(20)}:    ${STR(fg.total, 3)}  =>    ${STR(fg.wrong, 3)}  =>   ${STR(fg.percentWrong, 3)}`);
    });
    s.say(17, 4, "Waktu yang Anda Gunakan :   " + durationText(r.durationSec));
    s.say(18, 4, `Tingkat Ketelitian Anda :  ${STR(r.accuracy, 3)} %  => `);
    s.say(19, 4, `Tingkat Kecepatan Anda  : ${STR(r.speed, 4)} epm ( ${r.keystrokes} entakan ) => `);
    s.say(17, 57, "Nilai Anda : " + STR(r.grade, 5, 2));
    s.say(18, 57, "Nilai      : " + STR(r.accuracyGrade, 5, 2));
    s.say(19, 57, "Nilai      : " + STR(r.speedGrade, 5, 2));
    s.say(24, 0, " ".repeat(80), "gr+*/n");
    s.say(24, 25, "Tekan Enter =\u25ba Selesai ....!", "gr+*/n");

    // The original swallowed six keypresses so a fast typist could not skip this screen by accident;
    // here keys are ignored for 1.5 s, then Enter continues.
    let readyAt = null;
    this.setMode({
      tick(now) {
        readyAt ??= now + 1500;
      },
      key(k, now) {
        if (readyAt !== null && now >= readyAt && k === "Enter") app.goLayur(() => app.goMenu());
      },
    });
  }

  // ───────────────────────────── MIA: today's results (teacher view) ─────────────────────────────
  goReport() {
    const app = this;
    const s = this.s;
    const today = dateText();
    const rows = this.results.filter((x) => x.date === today);
    if (!rows.length) {
      s.setColor("w+/n");
      s.clear();
      s.say(12, 20, "Sorry belum ada yang latihan hari ini !");
      s.say(24, 64, "Tekan Enter donk");
      this.mode = { key: (k) => k === "Enter" && app.goMenu() };
      return;
    }
    const PER_PAGE = 18; // rows 4–21
    let page = 0;
    const pages = Math.ceil(rows.length / PER_PAGE);
    function draw() {
      s.setColor("bg+/b");
      s.clear();
      s.say(0, 22, "Hasil Latihan Tanggal : " + today);
      s.say(1, 3, "┌─────┬───────────┬────────────────────────┬──────┬──────┬──────┬───────┐");
      s.say(2, 3, "│ No. │    NIS    │       Nama  Siswa      │ Kode │ Kcpt │ Ktpt │ Nilai │");
      s.say(3, 3, "├─────┼───────────┼────────────────────────┼──────┼──────┼──────┼───────┤");
      let n = 4;
      rows.slice(page * PER_PAGE, (page + 1) * PER_PAGE).forEach((x, i) => {
        const num = page * PER_PAGE + i + 1;
        s.say(n, 3, "│     │           │                        │      │      │      │       │");
        s.say(n, num > 9 ? 5 : 6, `${num}.`);
        s.say(n, 11, x.reg.slice(0, 10));
        s.say(n, 23, x.nama.slice(0, 20));
        s.say(n, 48, x.code);
        s.say(n, 55, STR(x.speed, 3));
        s.say(n, 62, STR(x.accuracy, 3));
        s.say(n, 69, STR(x.grade, 5, 2));
        n += 1;
      });
      s.say(n, 3, "└─────┴───────────┴────────────────────────┴──────┴──────┴──────┴───────┘");
      const hal = "Halaman : " + STR(page + 1, 2);
      s.say(n + 1, 75 - hal.length, hal);
      if (page < pages - 1) {
        const msg = "Tekan Enter =\u25ba Lihat Halaman " + STR(page + 2, 2);
        s.say(24, centre(msg), msg);
      } else s.say(24, 29, "Tekan Enter =\u25ba Keluar");
    }
    this.setMode({
      enter: draw,
      key(k) {
        if (k !== "Enter") return;
        if (page < pages - 1) {
          page += 1;
          draw();
        } else app.goMenu();
      },
    });
  }

  // ───────────────────────────── AKHIR: leaving the program ─────────────────────────────
  goExit() {
    const app = this;
    const s = this.s;
    s.setColor("bg+/n");
    s.clear();
    const fio = "Waktu yang Anda Gunakan :   " + durationText(Math.round((Date.now() - this.sessionStart) / 1000));
    s.say(0, 80 - fio.length, fio);
    s.setColor("gr+*/n");
    s.say(2, 58, "Salam Hangat Roma-Romi");
    let enters = 0;
    this.setMode({
      key(k) {
        if (k === "Escape") return app.goLayur(() => app.goPrompt());
        if (k === "Enter" && ++enters >= 5) s.say(24, 21, "Tekan Esc Dong, Cacingan Dech Luuu !!!");
      },
    });
  }

  /** After quitting: a DOS prompt; Enter runs the program again. */
  goPrompt() {
    const app = this;
    const s = this.s;
    s.setColor("w/n");
    s.clear();
    s.say(0, 0, "C:\\>");
    s.cursor = { row: 0, col: 4, visible: true };
    let typed = "";
    this.setMode({
      enter() {
        s.cursor.visible = true;
      },
      key(k) {
        if (k === "Enter") {
          const cmd = typed.trim();
          if (cmd === "" || /^(romaromi|x)(\.exe|\.bat)?$/i.test(cmd)) return app.start();
          s.fill(0, 0, 24, 79, " ", "w/n");
          s.say(0, 0, "C:\\>" + cmd.toUpperCase(), "w/n");
          s.say(1, 0, "Bad command or file name", "w/n");
          s.say(3, 0, "C:\\>", "w/n");
          typed = "";
          s.cursor.row = 3;
          s.cursor.col = 4;
          return;
        }
        if (k === "Backspace" && typed) typed = typed.slice(0, -1);
        else if (isPrintable(k) && typed.length < 70) typed += k;
        s.say(s.cursor.row, 4, typed.toUpperCase() + " ", "w/n");
        s.cursor.col = 4 + typed.length;
      },
    });
  }

  // ───────────────────────────── LAYUR: CRT power-off animation ─────────────────────────────
  goLayur(then) {
    const s = this.s;
    const steps = [];
    let a = 0;
    let b = 24;
    while (a <= 11 || b === 13) {
      const [ca, cb] = [a, b];
      steps.push(() => {
        s.fill(ca, 0, ca, 79, " ", "w+/n");
        s.fill(cb, 0, cb, 79, " ", "w+/n");
        s.say(ca + 1, 0, "─".repeat(80), "w+/n");
        s.say(cb - 1, 0, "─".repeat(80), "w+/n");
      }, null);
      a += 1;
      b -= 1;
    }
    a = 0;
    b = 79;
    while (a <= 39 || b === 41) {
      const [ca, cb] = [a, b];
      steps.push(() => {
        s.fill(12, ca, 12, ca, " ", "w+/n");
        s.fill(12, cb, 12, cb, " ", "w+/n");
      });
      a += 1;
      b -= 1;
    }
    steps.push(() => s.say(12, a, "+", "w+/n"), null, null, null, null, null, null, () => s.say(12, a, " ", "w+/n"));
    let i = 0;
    let last = null;
    this.setMode({
      enter() {
        s.cursor.visible = false;
      },
      tick(now) {
        if (last !== null && now - last < 16) return;
        last = now;
        const step = steps[i++];
        if (step) step();
        if (i >= steps.length) then();
      },
    });
  }
}
