// 80x25 VGA text-mode screen drawn on a 640x400 canvas with the real 8x16 ROM font.
// The drawing API mirrors what the 2002 Clipper program used: SETCOLOR strings, @ row,col SAY,
// SCROLL (clear a region), DISPBOX and the program's own WINDOWS() bevel boxes.
import { VGA_FONT_B64 } from "./font.js";
import { cp437 } from "./cp437.js";

export const COLS = 80;
export const ROWS = 25;
const CELL_W = 8;
const CELL_H = 16;

/** Standard VGA 16-colour text palette. */
export const PALETTE = [
  [0, 0, 0], [0, 0, 170], [0, 170, 0], [0, 170, 170], [170, 0, 0], [170, 0, 170], [170, 85, 0], [170, 170, 170],
  [85, 85, 85], [85, 85, 255], [85, 255, 85], [85, 255, 255], [255, 85, 85], [255, 85, 255], [255, 255, 85], [255, 255, 255],
];

const COLOR_CODES = { n: 0, b: 1, g: 2, bg: 3, gb: 3, r: 4, rb: 5, br: 5, gr: 6, rg: 6, w: 7 };

/**
 * One Clipper colour pair ("w+/b", "gr+*\/n", "rb/n+") → VGA attribute byte.
 * Verified against the original in DOSBox: "+" brightens the foreground only when written on the
 * foreground side ("rb/n+" draws normal magenta), and "*" anywhere means blink.
 */
export function parsePair(pair) {
  const [fgRaw = "w", bgRaw = "n"] = pair.split("/");
  const clean = (s) => s.replace(/[+*]/g, "").trim().toLowerCase();
  const fg = (COLOR_CODES[clean(fgRaw)] ?? 7) + (fgRaw.includes("+") ? 8 : 0);
  const bg = COLOR_CODES[clean(bgRaw)] ?? 0;
  return (pair.includes("*") ? 0x80 : 0) | (bg << 4) | fg;
}

/** SETCOLOR("standard,enhanced") → { std, enh } attributes. */
export function parseColor(spec) {
  const [std = "w/n", enh = "n/w"] = spec.split(",");
  return { std: parsePair(std), enh: parsePair(enh) };
}

const BEVEL_STYLES = { // WINDOWS(top, left, width, height, style): [light edge, dark edge]
  1: ["W+/W", "N/W"], 2: ["N/W", "W+/W"], 3: ["bg+/bg", "n/bg"], 4: ["n/bg", "bg+/bg"],
  5: ["w/rb", "n/rb"], 6: ["n/rb", "w/rb"], 7: ["n/b", "b+/b"], 8: ["b+/b", "n/b"],
};

function decodeFont() {
  const bin = atob(VGA_FONT_B64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return bytes;
}

export class Screen {
  constructor(canvas) {
    this.canvas = canvas;
    canvas.width = COLS * CELL_W;
    canvas.height = ROWS * CELL_H;
    this.ctx = canvas.getContext("2d");
    this.image = this.ctx.createImageData(canvas.width, canvas.height);
    this.pixels = new Uint32Array(this.image.data.buffer);
    this.font = decodeFont();
    this.chars = new Uint8Array(COLS * ROWS).fill(0x20);
    this.attrs = new Uint8Array(COLS * ROWS).fill(0x07);
    this.colors = PALETTE.map(([r, g, b]) => (255 << 24) | (b << 16) | (g << 8) | r); // little-endian RGBA
    this.color = parseColor("w/n");
    this.cursor = { row: 0, col: 0, visible: false };
    this.dirty = true;
    this.lastPhase = -1;
  }

  setColor(spec) {
    this.color = parseColor(spec);
  }

  /** @ row, col SAY text — in the standard colour, or an explicit attribute / colour string. */
  say(row, col, text, color) {
    const attr = color === undefined ? this.color.std : typeof color === "string" ? parsePair(color) : color;
    row = Math.trunc(row);
    col = Math.trunc(col);
    if (row < 0 || row >= ROWS) return;
    for (const ch of String(text)) {
      if (col >= COLS) break;
      if (col >= 0) {
        const i = row * COLS + col;
        this.chars[i] = typeof ch === "number" ? ch : cp437(ch);
        this.attrs[i] = attr;
      }
      col += 1;
    }
    this.dirty = true;
  }

  /** Put one raw CP437 code (0–255) at a cell. */
  putCode(row, col, code, color) {
    const attr = color === undefined ? this.color.std : typeof color === "string" ? parsePair(color) : color;
    if (row < 0 || row >= ROWS || col < 0 || col >= COLS) return;
    const i = row * COLS + col;
    this.chars[i] = code & 0xff;
    this.attrs[i] = attr;
    this.dirty = true;
  }

  /** SCROLL(top, left, bottom, right) with no count = clear the region in the standard colour. */
  fill(top, left, bottom, right, ch = " ", color) {
    const attr = color === undefined ? this.color.std : typeof color === "string" ? parsePair(color) : color;
    const code = cp437(ch);
    for (let r = Math.max(0, top); r <= Math.min(ROWS - 1, bottom); r++) {
      for (let c = Math.max(0, left); c <= Math.min(COLS - 1, right); c++) {
        this.chars[r * COLS + c] = code;
        this.attrs[r * COLS + c] = attr;
      }
    }
    this.dirty = true;
  }

  clear() {
    this.fill(0, 0, ROWS - 1, COLS - 1);
    this.cursor.visible = false;
  }

  /** DISPBOX(top, left, bottom, right, 1): single-line frame. */
  box(top, left, bottom, right, color) {
    this.say(top, left, "┌" + "─".repeat(right - left - 1) + "┐", color);
    this.say(bottom, left, "└" + "─".repeat(right - left - 1) + "┘", color);
    for (let r = top + 1; r < bottom; r++) {
      this.say(r, left, "│", color);
      this.say(r, right, "│", color);
    }
  }

  /** The program's WINDOWS() procedure: a 3-D frame lit from the top left; the interior is not cleared. */
  bevel(top, left, width, height, style) {
    const [light, dark] = BEVEL_STYLES[style];
    const bottom = top + height + 1;
    const right = left + width + 1;
    this.say(top, left, "┌" + "─".repeat(width), light);
    for (let r = top + 1; r < bottom; r++) this.say(r, left, "│", light);
    this.say(bottom, left, "└", light);
    this.say(bottom, left + 1, "─".repeat(width) + "┘", dark);
    for (let r = top + 1; r < bottom; r++) this.say(r, right, "│", dark);
    this.say(top, right, "┐", dark);
  }

  /** Draw to the canvas. Blinking text and the cursor follow the VGA rate (~1.9 Hz). */
  render(now) {
    const phase = Math.floor(now / 267) & 1;
    if (!this.dirty && phase === this.lastPhase) return;
    this.lastPhase = phase;
    this.dirty = false;
    const { chars, attrs, font, colors, pixels } = this;
    const W = COLS * CELL_W;
    for (let row = 0; row < ROWS; row++) {
      for (let col = 0; col < COLS; col++) {
        const i = row * COLS + col;
        const attr = attrs[i];
        const bg = colors[(attr >> 4) & 7];
        const hidden = attr & 0x80 && phase === 1;
        const fg = hidden ? bg : colors[attr & 15];
        const glyph = chars[i] * CELL_H;
        const cursorHere = this.cursor.visible && phase === 0 && this.cursor.row === row && this.cursor.col === col;
        let p = row * CELL_H * W + col * CELL_W;
        for (let y = 0; y < CELL_H; y++, p += W) {
          const bits = cursorHere && y >= 13 && y <= 14 ? 0xff : font[glyph + y];
          for (let x = 0; x < CELL_W; x++) pixels[p + x] = bits & (0x80 >> x) ? fg : bg;
        }
      }
    }
    this.ctx.putImageData(this.image, 0, 0);
  }
}
