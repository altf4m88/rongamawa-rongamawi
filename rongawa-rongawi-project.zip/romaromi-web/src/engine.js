// RomaRomi typing engine — behaviour recovered from the 2002 Clipper program (procedure KETIK),
// with the small deviations listed in docs/ENGINE_SPEC.md. Pure logic: no DOM, no timers; the caller
// passes timestamps in milliseconds. Works in the browser and in Node.

/** Finger table, in the order of the original results screen. `keys` = characters owned by the finger. */
export const FINGERS = [
  { id: "LP", name: "Kelingking Kiri", keys: "1qaz!QAZ`~" }, // backtick/tilde added (uncounted in 2002)
  { id: "LR", name: "Jari Manis Kiri", keys: "2wsx@WSX" },
  { id: "LM", name: "Jari Tengah Kiri", keys: "3edc#EDC" },
  { id: "LI", name: "Telunjuk Kiri", keys: "4rfv5tgb$RFV%TGB" },
  { id: "RI", name: "Telunjuk Kanan", keys: "6yhn7ujm^YHN&UJM" },
  { id: "RM", name: "Jari Tengah Kanan", keys: "8ik,*IK<" },
  { id: "RR", name: "Jari Manis Kanan", keys: "9ol.(OL>" },
  { id: "RP", name: "Kelingking Kanan", keys: "0p;/-'=)P:?_{\"+}|\\[]" },
  { id: "TH", name: "Ibu Jari", keys: " " },
];

const FINGER_BY_CHAR = new Map();
for (const f of FINGERS) for (const ch of f.keys) if (!FINGER_BY_CHAR.has(ch)) FINGER_BY_CHAR.set(ch, f.id);

/** Finger id responsible for a character, or null if no finger owns it. */
export function fingerOf(ch) {
  return FINGER_BY_CHAR.get(ch) ?? null;
}

/** Exercises where Esc cannot abort (the original hard-coded 23I as an exam text). */
export const EXAM_CODES = new Set(["23I"]);

// Keys that never reach the comparison (the original ignored arrows/Del; modifiers and F-keys never
// reached INKEY as characters). Backspace and Tab are NOT here: they count as wrong keystrokes.
const IGNORED_KEYS = new Set([
  "ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown", "Delete", "Insert", "Home", "End", "PageUp",
  "PageDown", "Shift", "Control", "Alt", "Meta", "CapsLock", "NumLock", "ScrollLock", "ContextMenu",
  "Dead", "Unidentified",
]);

/** Translate a KeyboardEvent.key value into the single character the original compared, or a control. */
function normaliseKey(key) {
  if (key === "Escape" || key === "Enter") return key;
  if (key === "Backspace") return "\b";
  if (key === "Tab") return "\t";
  if (key === "Spacebar") return " ";
  if (IGNORED_KEYS.has(key) || /^F\d{1,2}$/.test(key)) return null;
  return [...key].length === 1 ? key : null;
}

/**
 * Create a typing session.
 * @param {{code: string, lines: string[]}} exercise
 * @param {{timeLimitSec?: number|null}} options  time limit in seconds; null/0 = unlimited
 */
export function createSession(exercise, { timeLimitSec = null } = {}) {
  if (!exercise?.lines?.length) throw new Error("exercise has no lines");
  const lines = exercise.lines;
  const exam = EXAM_CODES.has(exercise.code);
  const limitMs = timeLimitSec > 0 ? timeLimitSec * 1000 : null;
  const tally = Object.fromEntries(FINGERS.map((f) => [f.id, { correct: 0, wrong: 0 }]));
  const typed = lines.map(() => []); // per line: [{ch, expected, ok}]
  let line = 0;
  let col = 0; // index into lines[line]; col === line length means "at end of line (needs Enter)"
  let startedAt = null;
  let endedAt = null;
  let status = "ready"; // ready | typing | finished | aborted

  function finish(now, why) {
    status = why;
    endedAt = now;
  }

  /**
   * Call regularly (e.g. every 200 ms). The 2002 program polled once a second and overshot the limit by ~1 s
   * (then hid it by showing "time − 1"); here the test ends exactly at the limit.
   */
  function tick(now) {
    if (status === "typing" && limitMs !== null && now - startedAt >= limitMs) {
      finish(startedAt + limitMs, "finished");
      return { type: "timeout" };
    }
    return null;
  }

  /**
   * Feed one key (KeyboardEvent.key) at time `now` (ms).
   * Returns an event: ignored | correct | wrong | newline | finished | timeout | aborted.
   */
  function press(key, now) {
    if (status === "finished" || status === "aborted") return { type: "ignored" };
    const timeout = tick(now);
    if (timeout) return timeout;
    const k = normaliseKey(key);
    if (k === null) return { type: "ignored" };
    if (k === "Escape") {
      if (exam) return { type: "ignored", reason: "exam" };
      finish(now, "aborted");
      return { type: "aborted" };
    }
    const target = lines[line];
    const atEnd = col >= target.length;
    if (k === "Enter" && !atEnd) return { type: "ignored", reason: "enter-before-end" };
    if (status === "ready") {
      status = "typing";
      startedAt = now; // the clock starts at the first accepted keystroke, as in the original
    }
    if (atEnd) {
      // End-of-line position: any accepted key moves on and is not scored (original behaviour).
      line += 1;
      col = 0;
      if (line >= lines.length) {
        finish(now, "finished");
        return { type: "finished" };
      }
      return { type: "newline", line };
    }
    const expected = target[col];
    const ok = k === expected;
    // Correct keys are credited to the finger that typed them; errors are charged to the finger that
    // should have typed the expected character. Characters no finger owns are not scored.
    const finger = ok ? fingerOf(k) : fingerOf(expected);
    if (finger) tally[finger][ok ? "correct" : "wrong"] += 1;
    typed[line].push({ ch: k, expected, ok });
    col += 1; // the cursor always advances: no corrections, a skipped character shifts the rest
    return { type: ok ? "correct" : "wrong", expected, key: k, finger, line, col };
  }

  function result() {
    const durationMs = startedAt === null ? 0 : (endedAt ?? startedAt) - startedAt;
    return computeResult(tally, durationMs);
  }

  return {
    press,
    tick,
    result,
    get status() { return status; },
    get position() { return { line, col }; },
    get typed() { return typed; },
    get exam() { return exam; },
    get startedAt() { return startedAt; },
  };
}

/** Clipper STR(x, n, 0) rounding: half away from zero. */
const roundHalfUp = (x) => Math.sign(x) * Math.floor(Math.abs(x) + 0.5);

/** Grade for accuracy (integer percent). Identical to the 2002 table (≤ 91 → 0). */
export function gradeAccuracy(acc) {
  if (acc >= 100) return 10;
  if (acc <= 91) return 0;
  return 10 - (100 - acc) * 0.5; // 99→9.5 … 92→6
}

const SPEED_TABLE = [ // [minimum epm, grade]; identical to the 2002 table (inclusive ranges, ≤ 139 → 0)
  [270, 10], [255, 9.5], [240, 9], [225, 8.5], [210, 8], [195, 7.5], [170, 7], [155, 6.5], [140, 6],
];

/** Grade for speed (integer keystrokes per minute). */
export function gradeSpeed(epm) {
  for (const [min, grade] of SPEED_TABLE) if (epm >= min) return grade;
  return 0;
}

export function computeResult(tally, durationMs) {
  const perFinger = FINGERS.map((f) => {
    const { correct, wrong } = tally[f.id];
    const total = correct + wrong;
    return { id: f.id, name: f.name, total, wrong, percentWrong: total ? roundHalfUp((wrong / total) * 100) : 0 };
  });
  const wrong = perFinger.reduce((s, f) => s + f.wrong, 0);
  const keystrokes = perFinger.reduce((s, f) => s + f.total, 0);
  const accuracyExact = keystrokes ? 100 - (wrong / keystrokes) * 100 : 0;
  const speedExact = durationMs > 0 ? keystrokes / (durationMs / 60000) : 0;
  const accuracy = roundHalfUp(accuracyExact);
  const speed = roundHalfUp(speedExact);
  const accuracyGrade = gradeAccuracy(accuracy);
  const speedGrade = gradeSpeed(speed);
  return {
    perFinger,
    keystrokes,
    wrong,
    correct: keystrokes - wrong,
    accuracy,
    speed,
    durationSec: Math.round(durationMs / 1000),
    accuracyGrade,
    speedGrade,
    grade: (accuracyGrade + speedGrade) / 2,
  };
}
