// Page bootstrap: keyboard capture (desktop and on-screen keyboards), beep, animation loop.
import { App } from "./app.js";

export function boot(exercises) {
  const canvas = document.getElementById("screen");
  const input = document.getElementById("keys");
  const crt = document.getElementById("crt");
  const soundButton = document.getElementById("sound");
  let audio = null;
  let soundOn = true;

  // The original beeped through the PC speaker (CHR(7)) on every wrong key.
  const beep = () => {
    if (!soundOn) return;
    try {
      audio ??= new AudioContext();
      const osc = audio.createOscillator();
      const gain = audio.createGain();
      osc.type = "square";
      osc.frequency.value = 880;
      gain.gain.value = 0.04;
      osc.connect(gain).connect(audio.destination);
      osc.start();
      osc.stop(audio.currentTime + 0.08);
    } catch {
      /* no audio available */
    }
  };

  const app = new App(canvas, exercises, { beep });
  window.__romaromi = app;

  input.addEventListener("keydown", (e) => {
    if (e.ctrlKey || e.metaKey || e.altKey || e.key === "Unidentified" || e.key === "Process") return;
    e.preventDefault();
    app.key(e.key, performance.now());
  });
  // On-screen keyboards often send characters only through input events.
  input.addEventListener("input", (e) => {
    if (e.inputType === "deleteContentBackward") app.key("Backspace", performance.now());
    for (const ch of input.value) app.key(ch === "\n" ? "Enter" : ch, performance.now());
    input.value = "";
  });

  const focus = () => input.focus({ preventScroll: true });
  crt.addEventListener("pointerdown", (e) => {
    e.preventDefault();
    focus();
  });
  input.addEventListener("focus", () => crt.classList.add("is-focused"));
  input.addEventListener("blur", () => crt.classList.remove("is-focused"));
  soundButton?.addEventListener("click", () => {
    soundOn = !soundOn;
    soundButton.setAttribute("aria-pressed", String(soundOn));
    soundButton.textContent = soundOn ? "Suara: nyala" : "Suara: mati";
    focus();
  });

  const frame = (now) => {
    app.tick(now);
    requestAnimationFrame(frame);
  };
  requestAnimationFrame(frame);
  focus();
}
