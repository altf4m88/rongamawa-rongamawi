#!/usr/bin/env node
// Bundle the web app into single self-contained HTML files (no server needed, works offline from file://).
//   dist/romaromi.html   standalone page: double-click to run (also what the Cloud Run server serves)
//   dist/artifact.html   same content without the <html>/<head>/<body> wrapper, for hosts that add their own
import { readFileSync, writeFileSync, mkdirSync } from "node:fs";

const root = new URL("../", import.meta.url);
const read = (p) => readFileSync(new URL(p, root), "utf8");
const ORDER = ["cp437.js", "font.js", "vga.js", "engine.js", "config.js", "app.js", "main.js"];

const stripModule = (src) => src.replace(/^import .*?;\s*$/gm, "").replace(/^export (?=(const|function|class|let) )/gm, "");
const code = ORDER.map((name) => `// ── src/${name}\n${stripModule(read(`src/${name}`))}`).join("\n");
const exercises = JSON.parse(read("data/exercises.json")).exercises;
const data = JSON.stringify(exercises).replaceAll("</", "<\\/");
const script = `<script>\n(() => {\n"use strict";\nconst EXERCISES = ${data};\n${code}\nboot(EXERCISES);\n})();\n</script>\n`;
const body = read("web/shell.html") + script;

const cut = body.indexOf("<main");
const standalone =
  '<!doctype html>\n<html lang="id">\n<head>\n<meta charset="utf-8">\n' +
  '<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">\n' +
  `${body.slice(0, cut)}</head>\n<body>\n${body.slice(cut)}</body>\n</html>\n`;

mkdirSync(new URL("dist/", root), { recursive: true });
writeFileSync(new URL("dist/artifact.html", root), body);
writeFileSync(new URL("dist/romaromi.html", root), standalone);
console.log(`dist/romaromi.html ${Math.round(standalone.length / 1024)} KB, dist/artifact.html ${Math.round(body.length / 1024)} KB`);
