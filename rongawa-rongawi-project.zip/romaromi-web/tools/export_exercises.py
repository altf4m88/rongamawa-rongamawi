#!/usr/bin/env python3
"""Export RomaRomi "Flicking Test" exercises from the legacy LATIH.DBF (dBase III) to JSON.

Rules reproduce exactly what the 2002 program (Clipper 5.01) showed to students,
as recovered from its p-code:
  * SET DELETED ON           -> records flagged deleted are not reachable
  * LOCATE FOR KODE_LAT == x -> first record with a code wins; later duplicates are unreachable
  * line loop BRS_01..BRS_23 -> the exercise ends at the first blank line; text after it is never shown
  * each line is trimmed     -> only the fixed-width (70 col) padding is removed; inner spacing is kept
Unreachable records are written to a separate archive file instead of being dropped.

Usage: python3 export_exercises.py data/source/LATIH.DBF data/
"""
import datetime, hashlib, json, os, struct, sys

LINE_FIELDS, LINE_WIDTH = 23, 70
CATEGORY = {"D": "drill", "I": "text", "E": "text", "C": "test"}
LANGUAGE = {"I": "id", "E": "en"}
# Unreachable records deliberately brought back (decision 2026-11-23): legacy record number -> new code
RESTORE = {51: ("28I", "deleted energy essay (Blok Cepu / Exxon Mobil), restored on request")}


def read_dbf(path):
    raw = open(path, "rb").read()
    count, header_len, rec_len = struct.unpack("<IHH", raw[4:12])
    fields, off = [], 32
    while raw[off] != 0x0D:
        fields.append((raw[off:off + 11].split(b"\0")[0].decode(), raw[off + 16]))
        off += 32
    expected = [("KD_LAT", 3), ("KODE_LAT", 3)] + [(f"BRS_{i:02d}", LINE_WIDTH) for i in range(1, LINE_FIELDS + 1)]
    if fields != expected:
        sys.exit(f"Unexpected LATIH.DBF structure: {fields}")
    records = []
    for i in range(count):
        rec = raw[header_len + i * rec_len: header_len + (i + 1) * rec_len]
        pos, values = 1, {}
        for name, width in fields:
            values[name] = rec[pos:pos + width].decode("cp437")
            pos += width
        records.append({"record": i + 1, "deleted": rec[:1] == b"*", **values})
    return raw, records


def effective_lines(rec):
    lines = []
    for i in range(1, LINE_FIELDS + 1):
        text = rec[f"BRS_{i:02d}"].rstrip(" ")
        if text.strip() == "":
            break
        lines.append(text)
    hidden = [i for i in range(len(lines) + 2, LINE_FIELDS + 1) if rec[f"BRS_{i:02d}"].strip()]
    return lines, hidden


def to_exercise(rec, lines):
    code = rec["KODE_LAT"].strip()
    kind = code[-1]
    return {
        "code": code,
        "category": CATEGORY.get(kind, "unknown"),
        "language": LANGUAGE.get(kind),
        "preview": lines[0][:60] if lines else "",
        "lines": lines,
        "stats": {"lines": len(lines), "characters": sum(len(l) for l in lines)},
        "legacy": {"record": rec["record"], "kd_lat": rec["KD_LAT"].strip()},
    }


def sort_key(ex):
    # menu order: drills (D), Indonesian (I), English (E), then test (C); numeric within each group
    code = ex["code"]
    return ("DIEC".find(code[-1]) % 5, int(code[:-1]) if code[:-1].isdigit() else 99)


def main():
    if len(sys.argv) != 3:
        sys.exit(__doc__)
    src, out_dir = sys.argv[1], sys.argv[2]
    raw, records = read_dbf(src)
    active, archive, seen = [], [], {}
    for rec in records:
        code = rec["KODE_LAT"].strip()
        lines, hidden = effective_lines(rec)
        if rec["deleted"]:
            reason = "deleted in LATIH.DBF (unreachable in the original program)"
        elif code in seen:
            reason = f"duplicate code; shadowed by record {seen[code]} (unreachable)"
        else:
            seen[code] = rec["record"]
            ex = to_exercise(rec, lines)
            if hidden and not (rec["record"] == 41 and hidden == [22]):  # rec 41 line 22 = licence counter, excluded
                ex["hidden_lines_after_blank"] = hidden
            active.append(ex)
            continue
        raw_lines = [rec[f"BRS_{i:02d}"].rstrip(" ") for i in range(1, LINE_FIELDS + 1)]
        while raw_lines and not raw_lines[-1].strip():
            raw_lines.pop()
        item = to_exercise(rec, lines)
        item.update({"reason": reason, "raw_lines": raw_lines})
        if rec["record"] in RESTORE:
            new_code, note = RESTORE[rec["record"]]
            ex = to_exercise(rec, lines)
            ex["code"] = new_code
            ex["restored"] = {"from_code": code, "note": note}
            active.append(ex)
            item["restored_as"] = new_code
        if any("\r" in l or "\n" in l for l in raw_lines):
            item["warning"] = "contains embedded CR/LF from a bad paste; text around them is damaged"
        archive.append(item)
    active.sort(key=sort_key)
    meta = {
        "schema_version": 1,
        "source": {"file": os.path.basename(src), "md5": hashlib.md5(raw).hexdigest(), "records": len(records)},
        "exported": datetime.date.today().isoformat(),
        "rules": __doc__.split("Rules")[1].split("Unreachable")[0].strip(),
    }
    os.makedirs(out_dir, exist_ok=True)
    with open(os.path.join(out_dir, "exercises.json"), "w", encoding="utf-8") as f:
        json.dump({**meta, "exercises": active}, f, ensure_ascii=False, indent=2)
    with open(os.path.join(out_dir, "exercises_archive.json"), "w", encoding="utf-8") as f:
        json.dump({**meta, "archived": archive}, f, ensure_ascii=False, indent=2)
    print(f"{len(active)} exercises -> exercises.json, {len(archive)} archived -> exercises_archive.json")


if __name__ == "__main__":
    main()
