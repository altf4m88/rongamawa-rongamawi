import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { createSession, fingerOf, gradeAccuracy, gradeSpeed, FINGERS } from "../src/engine.js";

const ex = (lines, code = "99X") => ({ code, lines });
const typeAll = (s, keys, t0 = 1000, step = 100) => {
  let t = t0;
  return [...keys].map((k) => s.press(k === "\n" ? "Enter" : k, (t += step)));
};
const finger = (r, id) => r.perFinger.find((f) => f.id === id);

test("every character in every exercise is owned by a finger", () => {
  const data = JSON.parse(readFileSync(new URL("../data/exercises.json", import.meta.url)));
  const orphans = new Set();
  for (const e of data.exercises) for (const l of e.lines) for (const ch of l) if (!fingerOf(ch)) orphans.add(ch);
  assert.deepEqual([...orphans], []);
  assert.equal(data.exercises.length, 52);
});

test("finger key sets do not overlap", () => {
  const seen = new Map();
  for (const f of FINGERS) for (const ch of f.keys) {
    assert.ok(!seen.has(ch), `${JSON.stringify(ch)} in ${seen.get(ch)} and ${f.id}`);
    seen.set(ch, f.id);
  }
});

test("perfect line, then Enter finishes the exercise", () => {
  const s = createSession(ex(["asdf jkl;"]));
  const ev = typeAll(s, "asdf jkl;\n");
  assert.equal(ev.at(-1).type, "finished");
  const r = s.result();
  assert.equal(r.keystrokes, 9);
  assert.equal(r.wrong, 0);
  assert.equal(r.accuracy, 100);
  assert.equal(finger(r, "TH").total, 1);
  assert.equal(finger(r, "LP").total, 1); // a
  assert.equal(finger(r, "RP").total, 1); // ;
});

test("substitution costs one error, charged to the expected character's finger", () => {
  const s = createSession(ex(["asdf"]));
  typeAll(s, "asdx\n"); // x instead of f: f belongs to left index
  const r = s.result();
  assert.equal(r.wrong, 1);
  assert.equal(finger(r, "LI").wrong, 1);
  assert.equal(finger(r, "LM").wrong, 0); // x's own finger is not blamed
});

test("an omitted character shifts the rest of the line (no resynchronisation)", () => {
  const s = createSession(ex(["abcdef"]));
  typeAll(s, "acdef"); // b skipped: c,d,e,f now all misaligned
  assert.equal(s.result().wrong, 4);
  assert.deepEqual(s.position, { line: 0, col: 5 });
});

test("Backspace is a wrong keystroke and still advances", () => {
  const s = createSession(ex(["ab"]));
  s.press("a", 1); s.press("Backspace", 2);
  const r = s.result();
  assert.equal(r.wrong, 1);
  assert.equal(finger(r, "LP").wrong, 0);
  assert.equal(finger(r, "LI").wrong, 1); // expected 'b' → left index
  assert.deepEqual(s.position, { line: 0, col: 2 });
});

test("Enter is ignored before the end of the line (2002 accepted it one character early)", () => {
  const s = createSession(ex(["ab", "cd"]));
  s.press("a", 1);
  assert.equal(s.press("Enter", 2).type, "ignored");
  s.press("b", 3);
  assert.equal(s.press("Enter", 4).type, "newline");
  assert.equal(s.result().wrong, 0);
});

test("any key at the end of a line moves on without scoring", () => {
  const s = createSession(ex(["ab", "cd"]));
  typeAll(s, "ab ");
  assert.deepEqual(s.position, { line: 1, col: 0 });
  assert.equal(s.result().keystrokes, 2);
});

test("arrows and modifiers are ignored and do not start the clock", () => {
  const s = createSession(ex(["ab"]));
  for (const k of ["ArrowLeft", "Shift", "F1", "Delete"]) assert.equal(s.press(k, 5).type, "ignored");
  assert.equal(s.status, "ready");
  s.press("a", 1000);
  assert.equal(s.startedAt, 1000);
});

test("Esc aborts, except in the exam exercise 23I", () => {
  const a = createSession(ex(["ab"]));
  a.press("a", 1);
  assert.equal(a.press("Escape", 2).type, "aborted");
  assert.equal(a.status, "aborted");
  const b = createSession(ex(["ab"], "23I"));
  b.press("a", 1);
  assert.equal(b.press("Escape", 2).type, "ignored");
  assert.equal(b.status, "typing");
});

test("time limit ends the test exactly at the deadline (2002 overshot by ~1 s)", () => {
  const s = createSession(ex(["abcdefghij"]), { timeLimitSec: 10 });
  s.press("a", 0); s.press("b", 1000);
  assert.equal(s.tick(9_999), null);
  assert.deepEqual(s.tick(10_000), { type: "timeout" });
  assert.equal(s.status, "finished");
  assert.equal(s.press("c", 60_000).type, "ignored");
  const r = s.result();
  assert.equal(r.durationSec, 10);
  assert.equal(r.keystrokes, 2);
  assert.equal(r.speed, 12); // 2 keystrokes / (10 s / 60)
});

test("speed and accuracy use whole-number rounding like Clipper STR()", () => {
  const s = createSession(ex(["aaaaaaaa"]));
  let t = 0;
  for (const k of "aaaaaaab") s.press(k, (t += 1000)); // 8 keys over 7 s, 1 wrong
  s.press("Enter", (t += 1000)); // end of line → finish at 8 s after start
  const r = s.result();
  assert.equal(r.accuracy, 88); // 87.5 → 88
  assert.equal(r.speed, 60); // 8 / (8/60)
});

test("accuracy grades match 2002: 100→10, 92→6, 91 and below → 0", () => {
  assert.deepEqual([100, 99, 98, 95, 92, 91, 50].map(gradeAccuracy), [10, 9.5, 9, 7.5, 6, 0, 0]);
});

test("speed grades match 2002, including every bracket edge", () => {
  const cases = { 300: 10, 270: 10, 269: 9.5, 255: 9.5, 254: 9, 240: 9, 239: 8.5, 224: 8, 209: 7.5,
    195: 7.5, 194: 7, 170: 7, 169: 6.5, 154: 6, 140: 6, 139: 0, 0: 0 };
  for (const [epm, grade] of Object.entries(cases)) assert.equal(gradeSpeed(Number(epm)), grade, `epm ${epm}`);
});

test("final grade is the mean of both grades; per-finger percentage", () => {
  const s = createSession(ex(["ff"]));
  s.press("f", 0); s.press("g", 1000); s.press("Enter", 1000);
  const r = s.result();
  assert.equal(finger(r, "LI").total, 2);
  assert.equal(finger(r, "LI").percentWrong, 50);
  assert.equal(r.grade, (r.accuracyGrade + r.speedGrade) / 2);
});
