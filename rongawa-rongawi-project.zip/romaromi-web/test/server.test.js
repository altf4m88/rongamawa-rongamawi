import { test, before, after } from "node:test";
import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { createHash } from "node:crypto";
import { readFileSync } from "node:fs";
import { gunzipSync } from "node:zlib";

const SERVER = new URL("../server/server.js", import.meta.url).pathname;
const APP = readFileSync(new URL("../dist/romaromi.html", import.meta.url), "utf8");
const procs = [];

function start(port, env = {}) {
  return new Promise((resolve, reject) => {
    const p = spawn(process.execPath, [SERVER], { env: { ...process.env, PORT: String(port), ...env } });
    procs.push(p);
    p.stdout.on("data", (d) => String(d).includes("listening") && resolve(`http://127.0.0.1:${port}`));
    p.on("exit", (code) => reject(new Error(`server exited ${code}`)));
  });
}
let open;
let locked;
before(async () => {
  open = await start(18080);
  locked = await start(18081, { BASIC_AUTH_USER: "guru", BASIC_AUTH_PASSWORD: "rahasia-uji" });
});
after(() => procs.forEach((p) => p.kill()));

test("serves the app with gzip, caching and security headers", async () => {
  const res = await fetch(open + "/");
  assert.equal(res.status, 200);
  assert.equal(res.headers.get("content-type"), "text/html; charset=utf-8");
  assert.equal(await res.text(), APP); // fetch transparently gunzips
  for (const h of ["content-security-policy", "x-content-type-options", "x-frame-options", "etag"]) assert.ok(res.headers.get(h), h);
  assert.equal(res.headers.get("x-robots-tag"), "noindex, nofollow");
  const raw = await fetch(open + "/", { headers: { "accept-encoding": "gzip" } });
  assert.equal(raw.headers.get("content-encoding"), "gzip");
});

test("CSP allows exactly the page's own inline script and style", async () => {
  const csp = (await fetch(open + "/")).headers.get("content-security-policy");
  const hash = (body) => `'sha256-${createHash("sha256").update(body, "utf8").digest("base64")}'`;
  const script = APP.match(/<script>([\s\S]*?)<\/script>/)[1];
  const style = APP.match(/<style>([\s\S]*?)<\/style>/)[1];
  assert.match(csp, new RegExp(`script-src ${hash(script).replace(/[+/]/g, "\\$&")}(;|$)`));
  assert.ok(csp.includes(hash(style)));
  assert.ok(!csp.includes("unsafe-inline"));
});

test("ETag revalidation returns 304", async () => {
  const etag = (await fetch(open + "/")).headers.get("etag");
  const res = await fetch(open + "/", { headers: { "if-none-match": etag } });
  assert.equal(res.status, 304);
});

test("only the app, the health check and HEAD/GET exist", async () => {
  assert.equal((await fetch(open + "/healthz")).status, 200);
  assert.equal((await fetch(open + "/index.html")).status, 200);
  assert.equal((await fetch(open + "/../server/server.js")).status, 404);
  assert.equal((await fetch(open + "/data/exercises.json")).status, 404);
  assert.equal((await fetch(open + "/", { method: "POST" })).status, 405);
  assert.equal((await fetch(open + "/", { method: "HEAD" })).status, 200);
});

test("basic auth: 401 without or with wrong credentials, 200 with the right ones, health check open", async () => {
  const b64 = (s) => Buffer.from(s).toString("base64");
  assert.equal((await fetch(locked + "/")).status, 401);
  assert.equal((await fetch(locked + "/", { headers: { authorization: "Basic " + b64("guru:salah") } })).status, 401);
  const ok = await fetch(locked + "/", { headers: { authorization: "Basic " + b64("guru:rahasia-uji") } });
  assert.equal(ok.status, 200);
  assert.equal((await fetch(locked + "/healthz")).status, 200);
});

test("refuses to start with only half of the basic-auth settings", async () => {
  const p = spawn(process.execPath, [SERVER], { env: { ...process.env, PORT: "18082", BASIC_AUTH_USER: "guru" } });
  const code = await new Promise((r) => p.on("exit", r));
  assert.equal(code, 1);
});
