// Minimal HTTP server for Cloud Run: serves the single-file app, nothing else. No dependencies.
//
// Environment:
//   PORT                 port to listen on (Cloud Run sets it; default 8080)
//   BASIC_AUTH_USER      optional: require this user name ...
//   BASIC_AUTH_PASSWORD  ... and this password (supply it from Secret Manager, never in plain config)
import { createServer } from "node:http";
import { createHash, timingSafeEqual } from "node:crypto";
import { readFileSync } from "node:fs";
import { gzipSync } from "node:zlib";

const APP_FILE = new URL("../dist/romaromi.html", import.meta.url);
const html = readFileSync(APP_FILE);
const gzipped = gzipSync(html, { level: 9 });
const etag = `"${createHash("sha256").update(html).digest("base64url").slice(0, 27)}"`;

// Content-Security-Policy pinned to the hashes of the page's own inline <script> and <style> blocks,
// so the page runs without allowing arbitrary inline code.
const hashesOf = (tag) =>
  [...html.toString("utf8").matchAll(new RegExp(`<${tag}>([\\s\\S]*?)</${tag}>`, "g"))]
    .map((m) => `'sha256-${createHash("sha256").update(m[1], "utf8").digest("base64")}'`)
    .join(" ");
const CSP = [
  "default-src 'none'",
  `script-src ${hashesOf("script")}`,
  `style-src ${hashesOf("style")} https://fonts.googleapis.com`,
  "font-src https://fonts.gstatic.com",
  "img-src 'self' data:",
  "base-uri 'none'",
  "form-action 'none'",
  "frame-ancestors 'none'",
].join("; ");

const SECURITY_HEADERS = {
  "Content-Security-Policy": CSP,
  "X-Content-Type-Options": "nosniff",
  "Referrer-Policy": "no-referrer",
  "X-Frame-Options": "DENY",
  "Permissions-Policy": "camera=(), microphone=(), geolocation=(), payment=()",
  "X-Robots-Tag": "noindex, nofollow", // internal school tool: keep it out of search engines
};

const authUser = process.env.BASIC_AUTH_USER ?? "";
const authPass = process.env.BASIC_AUTH_PASSWORD ?? "";
if ((authUser === "") !== (authPass === "")) {
  console.error("Set both BASIC_AUTH_USER and BASIC_AUTH_PASSWORD, or neither.");
  process.exit(1);
}
const authRequired = authUser !== "";
const digest = (s) => createHash("sha256").update(s, "utf8").digest();
const expected = digest(`${authUser}:${authPass}`);

function authorised(req) {
  if (!authRequired) return true;
  const header = req.headers.authorization ?? "";
  if (!header.startsWith("Basic ")) return false;
  const given = Buffer.from(header.slice(6), "base64").toString("utf8");
  return timingSafeEqual(digest(given), expected); // equal-length digests: constant-time compare
}

function log(req, status) {
  // One JSON line per request: Cloud Logging parses it into structured fields.
  console.log(JSON.stringify({ severity: status >= 500 ? "ERROR" : "INFO", httpRequest: {
    requestMethod: req.method, requestUrl: req.url, status, userAgent: req.headers["user-agent"] } }));
}

function send(req, res, status, headers, body) {
  res.writeHead(status, { ...SECURITY_HEADERS, ...headers });
  res.end(req.method === "HEAD" ? undefined : body);
  log(req, status);
}

export const server = createServer((req, res) => {
  const path = new URL(req.url, "http://localhost").pathname;
  if (path === "/healthz") return send(req, res, 200, { "Content-Type": "text/plain" }, "ok");
  if (req.method !== "GET" && req.method !== "HEAD") {
    return send(req, res, 405, { Allow: "GET, HEAD", "Content-Type": "text/plain" }, "Method not allowed");
  }
  if (path !== "/" && path !== "/index.html") {
    return send(req, res, 404, { "Content-Type": "text/plain" }, "Not found");
  }
  if (!authorised(req)) {
    return send(req, res, 401, { "WWW-Authenticate": 'Basic realm="RomaRomi", charset="UTF-8"', "Content-Type": "text/plain" }, "Login required");
  }
  const common = { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-cache", ETag: etag, Vary: "Accept-Encoding" };
  if (req.headers["if-none-match"] === etag) return send(req, res, 304, common);
  if (/\bgzip\b/.test(req.headers["accept-encoding"] ?? "")) {
    return send(req, res, 200, { ...common, "Content-Encoding": "gzip", "Content-Length": gzipped.length }, gzipped);
  }
  return send(req, res, 200, { ...common, "Content-Length": html.length }, html);
});

if (process.argv[1] && new URL(import.meta.url).pathname === process.argv[1]) {
  const port = Number(process.env.PORT) || 8080;
  server.listen(port, () => console.log(JSON.stringify({ severity: "INFO", message: `RomaRomi listening on ${port}`, basicAuth: authRequired })));
  // Cloud Run sends SIGTERM before stopping an instance: finish in-flight requests, then exit.
  process.on("SIGTERM", () => server.close(() => process.exit(0)));
}
