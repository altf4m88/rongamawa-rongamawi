# Deploying RomaRomi to Cloud Run (testing)

The service is one small container: a dependency-free Node server (`server/server.js`) that serves the
single-file app. The image build runs the full test suite first, so a failing test means no image.

## You need
- A Google Cloud project with billing enabled, and the `gcloud` CLI signed in (`gcloud auth login`).
- Nothing else: Cloud Build builds the container from this folder.

## Deploy
Private (default): only Google accounts you grant can open it.

    PROJECT=your-project-id ./deploy.sh

Open it through an authenticated tunnel from your own computer:

    gcloud run services proxy romaromi --project your-project-id --region asia-southeast2 --port 8080
    # then browse to http://localhost:8080

To let another Google account in: `gcloud run services add-iam-policy-binding romaromi --region asia-southeast2
--member user:someone@example.com --role roles/run.invoker` (they also use the proxy command).

Password mode, for lab testers without Google Cloud access: the link is reachable, but the browser asks for a
user name and password. The script creates a random password in Secret Manager the first time.

    PROJECT=your-project-id ACCESS=password ./deploy.sh
    gcloud secrets versions access latest --secret romaromi-test-password --project your-project-id

Switch back to private any time with the first command. Options: `REGION` (default `asia-southeast2`, Jakarta),
`SERVICE` (default `romaromi`), `AUTH_USER` (default `guru`), `SECRET` (default `romaromi-test-password`).

## Settings and cost
- 1 vCPU, 512 MiB, 0–2 instances, 30 s request timeout. With `min-instances 0` it costs nothing while idle;
  light testing normally stays inside Cloud Run's free tier (Cloud Build and Artifact Registry storage may add cents).
- Every response carries `X-Robots-Tag: noindex`, a strict Content-Security-Policy pinned to the page's own
  script and style hashes, and no-framing headers. Only `/`, `/index.html` and `/healthz` exist.
- Logs: Cloud Logging, one structured line per request.

## Remove it

    gcloud run services delete romaromi --region asia-southeast2 --project your-project-id
    gcloud secrets delete romaromi-test-password --project your-project-id   # if password mode was used

## Test the container locally

    docker build -t romaromi .
    docker run --rm -p 8080:8080 romaromi                      # open http://localhost:8080
    docker run --rm -p 8080:8080 -e BASIC_AUTH_USER=guru -e BASIC_AUTH_PASSWORD=test romaromi

## Know before testing
Results are still saved in each browser (the `MIA` list shows only what was typed on that device).
Central storage is the next step; the server is where its API will go.
