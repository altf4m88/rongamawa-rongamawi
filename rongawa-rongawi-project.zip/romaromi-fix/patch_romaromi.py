#!/usr/bin/env python3
"""Disarm the logic bomb in RomaRomi "Flicking Test" (ROMAROMI.EXE, Clipper 5.01, New Edition 2002).

What the original does (recovered from its p-code):
  * Startup tamper check: if the EXE is renamed or LATIH.DBF record 41 is edited -> RUN del *.obj / del *.exe
  * Startup key check + usage countdown (LATIH.DBF rec 41, BRS_22 cols 68-70): when the counter goes negative
    or the data is reordered -> fake "Abort, Retry, Fail?" screen -> RUN del *.obj / del *.exe
  * Exit routine decrements that counter.

This patch:
  1. jumps over the tamper check          (p-code @0x3FC28: PUSHSYM FILE -> JMP 0x3FF09)
  2. jumps over the key/counter check     (p-code @0x3FFF0: PUSHM KUNCI  -> JMP 0x40201)
  3. jumps over the counter write-back    (p-code @0x41C62: PUSHM CONT   -> JMP 0x41C93)
  4. rewrites the 4 'del *.exe'/'del *.obj' literals to 'rem ...' (defence in depth)
Nothing else changes; the file size stays identical. The original is never modified in place.

Usage:  python3 patch_romaromi.py ROMAROMI.EXE [OUTPUT.EXE]
"""
import hashlib, sys

ORIGINAL_MD5 = "d4a5c6cc25c0cc406a843a0a4df8c294"
PATCHES = [  # (offset, expected original bytes, new bytes, description)
    (0x3FC28, bytes.fromhex("131400"), bytes.fromhex("1ede02"), "skip tamper check"),
    (0x3FFF0, bytes.fromhex("0f1f00"), bytes.fromhex("1e0e02"), "skip key/countdown check + fake DOS error"),
    (0x41C62, bytes.fromhex("0f5700"), bytes.fromhex("1e2e00"), "skip countdown write-back"),
]
STRINGS = [(b"\x01\x09del *.obj\x00", b"\x01\x09rem *.obj\x00"),
           (b"\x01\x09del *.exe\x00", b"\x01\x09rem *.exe\x00")]

def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    src = sys.argv[1]
    dst = sys.argv[2] if len(sys.argv) > 2 else src.rsplit(".", 1)[0] + "_SAFE.EXE"
    if dst == src:
        sys.exit("Refusing to overwrite the input; give a different output path.")
    data = bytearray(open(src, "rb").read())
    md5 = hashlib.md5(data).hexdigest()
    if md5 != ORIGINAL_MD5:
        print(f"WARNING: md5 {md5} is not the known 2002 build; checking patch sites byte-by-byte anyway.")
    for off, old, new, what in PATCHES:
        cur = bytes(data[off:off + len(old)])
        if cur == new:
            print(f"  [already] {what}"); continue
        if cur != old:
            sys.exit(f"ABORT: unexpected bytes at 0x{off:X} ({cur.hex()}), different build - not patching.")
        data[off:off + len(new)] = new
        print(f"  [patched] 0x{off:05X} {what}")
    for old, new in STRINGS:
        n = data.count(old)
        data[:] = data.replace(old, new)
        print(f"  [patched] {n} x {old[2:-1].decode()!r} -> {new[2:-1].decode()!r}")
    if b"del *.exe" in data or b"del *.obj" in data:
        sys.exit("ABORT: delete command still present.")
    open(dst, "wb").write(data)
    print(f"Wrote {dst}  md5={hashlib.md5(data).hexdigest()}")

if __name__ == "__main__":
    main()
