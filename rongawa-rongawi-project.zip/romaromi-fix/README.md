# RomaRomi "Flicking Test" (2002) – logic bomb disarmed

`ROMAROMI.EXE` in this folder is the original 2002 build with its self-destruct code disabled.
Drop-in replacement: same size, same data files, same behaviour otherwise.

| | MD5 |
|---|---|
| Original (armed)  | `d4a5c6cc25c0cc406a843a0a4df8c294` |
| Patched (safe)    | `a8c63d2e8077632bee26f6f2bccaa220` |

## What was changed (16 bytes)
| Offset | Was | Now | Effect |
|---|---|---|---|
| 0x3FC28 | `13 14 00` | `1E DE 02` | jump over the tamper check (renamed EXE / edited LATIH.DBF) |
| 0x3FFF0 | `0F 1F 00` | `1E 0E 02` | jump over the key + countdown check and the fake "Abort, Retry, Fail?" screen |
| 0x41C62 | `0F 57 00` | `1E 2E 00` | stop decrementing the hidden counter (LATIH.DBF rec 41, BRS_22, cols 68–70) |
| 4 places | `del *.exe` / `del *.obj` | `rem *.exe` / `rem *.obj` | delete commands neutralised even if reached |

Left unchanged: `RUN del *.idx` on exit (deletes index files in the current folder; the program rebuilds `id.idx` itself).

## Tested in DOSBox 0.74 with decoy DECOY.EXE / GAME.EXE / MYWORK.OBJ in the folder
| Scenario | Original | Patched |
|---|---|---|
| EXE renamed to ROMA.EXE | "Your Disk Infected" box, **all .exe/.obj deleted (incl. itself)**, crash | starts normally, nothing deleted |
| Counter set to -1, "A" pressed 4× | fake disk error → **all .exe/.obj deleted**, crash | starts normally, nothing deleted |
| Normal practice + exit | counter 310 → 309 | counter stays 310 |

## Rolling out to lab PCs
Replace every copy of the original with the patched file. Copies may be renamed, so search by hash (PowerShell):

    Get-ChildItem C:\ -Recurse -Include *.exe -ErrorAction SilentlyContinue |
      Get-FileHash -Algorithm MD5 | Where-Object Hash -eq 'D4A5C6CC25C0CC406A843A0A4DF8C294'

Other builds: `python3 patch_romaromi.py <ROMAROMI.EXE> <OUT.EXE>` — it verifies every byte before patching and refuses unknown builds.
